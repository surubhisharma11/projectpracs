package com.lnt.hr.eligibility;

import org.springframework.stereotype.Service;

import com.lnt.hr.entities.Scholarship;

@Service("MinorityBased")
public class MinorityBased implements CheckEligibility
{

	@Override
	public String checkEligibility(Scholarship scholarship) 
	{
		int tenthPercentage = scholarship.getTenthPercentObtained();
		int twelthPercentage =scholarship.getTwelthPercentObtained();
		String community=scholarship.getCommunity();
		
		if((tenthPercentage >= 60) && (twelthPercentage >=60))
		{
			if ((community.equals("SC")) || ( community.equals("ST")))
			{
				String query = " SELECT * FROM SCHOLARSHIP WHERE (APPLICATIONID , RATIONCARDNUMBER , FATHERNAME) "
						+ "IN ( SELECT APPLICATIONID , RATIONCARDNUMBER , FATHERNAME FROM SCHOLARSHIP GROUP BY "
						+ " APPLICATIONID, RATIONCARDNUMBER , FATHERNAME HAVING COUNT(*) >=2) ";
				
				
				
			}
		return null;
		}
		return null;
	}

}
