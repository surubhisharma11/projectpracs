package com.lnt.hr.daos;

import java.util.List;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

public interface InstituteRegistrationDao 
{
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration) throws RegistrationException;
	
	public List<InstituteRegistration> getInsList() throws RegistrationException;
	
	public InstituteRegistration getInsDetails(long instituteCode) throws RegistrationException;

}
